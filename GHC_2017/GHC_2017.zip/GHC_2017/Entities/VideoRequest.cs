﻿namespace GHC_2017.Entities
{
    public class VideoRequest
    {
        public Video Video;
        public int TotalRequests;
    }
}