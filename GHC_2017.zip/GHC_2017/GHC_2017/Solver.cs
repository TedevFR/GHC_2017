﻿using GHC.Parsing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GHC_2017
{
    public class Solver
    {
        #region Fields/Properties
        private string _inputFilePath;
        private string _outputFilePath;
        #endregion

        #region Constructor
        public Solver(string inputFilePath, string outputFilePath)
        {
            _inputFilePath = inputFilePath;
            _outputFilePath = outputFilePath;
        }
        #endregion

        #region Public methods
        public void Solve()
        {
            ParseInput();
            //Slice();
            CreateOutput();
            DisplayPoints();
        }
        #endregion

        #region Private methods
        private void ParseInput()
        {
            using (Parser parser = new Parser(_inputFilePath))
            {
                string line = parser.GetStringLine();
                var line1Tab = line.Split(' ');

                //nbRows = int.Parse(line1Tab[0]);
            }
        }
        
        private void CreateOutput()
        {
            using (FileCreator fc = new FileCreator(_outputFilePath))
            {
                //fc.WriteLine(Slices.Count().ToString());
            }
        }

        private void DisplayPoints()
        {
            //Console.WriteLine();
        }
        #endregion
    }
}