﻿using System;

namespace GHC_2017
{
    class Program
    {
        const string inputFilePathExample = "Inputs/example.in";
        const string inputFilePathSmall = "Inputs/small.in";
        const string inputFilePathMedium = "Inputs/medium.in";
        const string inputFilePathBig = "Inputs/big.in";

        const string outputFilePathExample = "Outputs/example.out";
        const string outputFilePathSmall = "Outputs/small.out";
        const string outputFilePathMedium = "Outputs/medium.out";
        const string outputFilePathBig = "Outputs/big.out";

        static void Main(string[] args)
        {
            Solve(inputFilePathExample, outputFilePathExample);
            Solve(inputFilePathSmall, outputFilePathSmall);
            Solve(inputFilePathMedium, outputFilePathMedium);
            Solve(inputFilePathBig, outputFilePathBig);

            Console.ReadKey();
        }

        private static void Solve(string inputFilePathExample, string outputFilePathExample)
        {
            Solver solver = new Solver(inputFilePathExample, outputFilePathExample);
            solver.Solve();
        }
    }
}